package com.outjected.email.api;

public enum ICalMethod {
    PUBLISH,
    REQUEST,
    REFRESH,
    CANCEL,
    ADD,
    REPLY,
    COUNTER,
    DECLINECOUNTER;
}
